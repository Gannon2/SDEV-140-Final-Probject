# Programmed by Gannon Stephens on 3/2/23 (WIP1)
# SDEV 140 Final Project
import tkinter as tk # imports Tkinter
# WIP1: Built the basic window
window = tk.Tk()
window.geometry("350x400") # resizes the window

window.title("Calculator") # names the window

calc = "" # sets the input blank

def add_to_calc(symbol): # lines 10 through 34 define different functions that will be used.
    global calc
    calc += str(symbol)
    tresult.delete(1.0, "end")
    tresult.insert(1.0, calc)
def evaluate_calc():
    global calc
    try:
        result = str(eval(calculation))
        calc = ""
        tresult.delete(1.0, "end")
        tresult.insert(1.0, calc)
    except:
        clear()
        tresult.insert(1.0, "ERROR")
        pass


def clear():
    global calc
    calc = ""
    tresult.delete(1.0, "end")
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Lines 36 through 59 are going to be the buttons.
tresult = tk.Text(window, height = 2, width=16, font=("Arial", 24))
tresult.grid(columnspan=5)

button1 = tk.Button(window, text="1", command=lambda: add_to_calc(1), width=5, font=('Arial', 14))
button1.grid(row=2, column=1)
button2 = tk.Button(window, text="2", command=lambda: add_to_calc(2), width=5, font=('Arial', 14))
button2.grid(row=2, column=2)
button3 = tk.Button(window, text="3", command=lambda: add_to_calc(3), width=5, font=('Arial', 14))
button3.grid(row=2, column=3)
button4 = tk.Button(window, text="4", command=lambda: add_to_calc(4), width=5, font=('Arial', 14))
button4.grid(row=3, column=1)
button5 = tk.Button(window, text="5", command=lambda: add_to_calc(5), width=5, font=('Arial', 14))
button5.grid(row=3, column=2)
button6 = tk.Button(window, text="6", command=lambda: add_to_calc(6), width=5, font=('Arial', 14))
button6.grid(row=3, column=3)
button7 = tk.Button(window, text="7", command=lambda: add_to_calc(7), width=5, font=('Arial', 14))
button7.grid(row=4, column=1)
button8 = tk.Button(window, text="8", command=lambda: add_to_calc(8), width=5, font=('Arial', 14))
button8.grid(row=4, column=2)
button9 = tk.Button(window, text="9", command=lambda: add_to_calc(9), width=5, font=('Arial', 14))
button9.grid(row=4, column=3)
button10 = tk.Button(window, text="10", command=lambda: add_to_calc(10), width=5, font=('Arial', 14))
button10.grid(row=5, column=2)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 





window.mainloop() # executes main module
