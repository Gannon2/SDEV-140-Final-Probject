# Programmed by Gannon Stephens on 3/2/23 (WIP1)
# SDEV 140 Final Project
#      J. Treacy - add operand plus key with method display in messagebox
#                  WIP2 Part of review 2 checkin.
#                  WIP3 giving buttons functions
#      GS        - WIP Final finishing touches
import tkinter as tk # imports Tkinter
import tkinter.messagebox     # JCT Messagebox widget to display results

# WIP1: Built the basic window
window = tk.Tk()
window.geometry("300x400") # resizes the window

window.title("Calculator") # names the window

calc = "" # sets the input blank
global oper1 # makes operator 1 global
oper1 = 0
global oper2# makes operator 2 global
oper2 = 0
global lastOper # makes the last operator global
lastOper = ""
# Lines 24 through 162 define different functions that will be used.
# Each of these test and calculate based on the different operators that will be used on the application.
def add_to_calc(symbol):
    global calc
    calc += str(symbol)
    tresult.delete(1.0, "end")
    tresult.insert(1.0, calc)
def evaluate_calc():
    global calc
    try:
        calculation = calc
        result = str(eval(calculation))
        tresult.delete(1.0, "end")
        tresult.insert(1.0, calc)
      
    except:
        clear()
        tresult.insert(1.0, "ERROR")
        pass


def clear():
    global calc
    calc = ""
    oper1 = 0
    oper2 = 0
    lastOper = ""
    tresult.delete(1.0, "end")
# method below... added JCT WIP2 - To do capture and process second operand.
def addOper():
    global oper1
    global oper2
    global lastOper

    operInpt=calc
    if operInpt == "":
        tkinter.messagebox.showinfo('Result'
                                    f'Blank Operand')  # displays a message notifying the user of a blank operand error.
    else:
        lastOper = '+'
        numEnter = float(operInpt)
        if oper1 == 0:
            oper1 = numEnter
            result = numEnter
        else:
            oper2 = numEnter
            result = oper1 + oper2
            oper1 = result

        tkinter.messagebox.showinfo('Result',
                                    f'Numeric result is {result:10.2f}.') # displays the current result of the user's equation
        clear()
def subOper():
    global oper1
    global oper2
    global lastOper

    operInpt=calc
    if operInpt == "":
        tkinter.messagebox.showinfo('Result'
                                    f'Blank Operand')
    else:
        lastOper = '-'
        numEnter = float(operInpt)
        if oper1 == 0:
            oper1 = numEnter
            result = numEnter
        else:
            oper2 = numEnter
            result = oper1 - oper2
            oper1 = result

        tkinter.messagebox.showinfo('Result',
                                    f'Numeric result is {result:10.2f}.')
    clear()
def mulOper():
    global oper1
    global oper2
    global lastOper

    operInpt=calc
    if operInpt == "":
        tkinter.messagebox.showinfo('Result'
                                    f'Blank Operand')
    else:
        lastOper = '*'
        numEnter = float(operInpt)
        if oper1 == 0:
            oper1 = numEnter
            result = numEnter
        else:
            oper2 = numEnter
            result = oper1 * oper2
            oper1 = result

        tkinter.messagebox.showinfo('Result',
                                    f'Numeric result is {result:10.2f}.')
    clear()
def divOper():
    global oper1
    global oper2
    global lastOper

    operInpt=calc
    if operInpt == "":
        tkinter.messagebox.showinfo('Result'
                                    f'Blank Operand')
    else:
        lastOper = '/'
        numEnter = float(operInpt)
        if oper1 == 0:
            oper1 = numEnter
            result = numEnter
        else:
            oper2 = numEnter
            result = oper1 / oper2
            oper1 = result

        tkinter.messagebox.showinfo('Result',
                                    f'Numeric result is {result:10.2f}.')
    clear()
def equalOper():
    global oper1
    global oper2
    global lastOper
    global calc

    operInpt=calc
    if operInpt == "":
        tkinter.messagebox.showinfo('Result'
                                    f'Blank Operand')
    else:
        oper2 = numEnter
        if lastOper == "+":
            result = oper1 + oper2
        elif lastOper == "-":
            result = oper1 - oper2
        elif lastOper == "*":
            result = oper1 * oper2
        elif lastOper == "/":
            result = oper1 / oper2
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Lines 36 through 205 are the buttons, these are used to allow the user to input things.
tresult = tk.Text(window, height = 2, width=17, font=("Arial", 24))
tresult.grid(columnspan=5)

button1 = tk.Button(window, text="1", command=lambda: add_to_calc(1), width=5, font=('Arial', 14))
button1.grid(row=2, column=1)
button2 = tk.Button(window, text="2", command=lambda: add_to_calc(2), width=5, font=('Arial', 14))
button2.grid(row=2, column=2)
button3 = tk.Button(window, text="3", command=lambda: add_to_calc(3), width=5, font=('Arial', 14))
button3.grid(row=2, column=3)
button4 = tk.Button(window, text="4", command=lambda: add_to_calc(4), width=5, font=('Arial', 14))
button4.grid(row=3, column=1)
button5 = tk.Button(window, text="5", command=lambda: add_to_calc(5), width=5, font=('Arial', 14))
button5.grid(row=3, column=2)
button6 = tk.Button(window, text="6", command=lambda: add_to_calc(6), width=5, font=('Arial', 14))
button6.grid(row=3, column=3)
button7 = tk.Button(window, text="7", command=lambda: add_to_calc(7), width=5, font=('Arial', 14))
button7.grid(row=4, column=1)
button8 = tk.Button(window, text="8", command=lambda: add_to_calc(8), width=5, font=('Arial', 14))
button8.grid(row=4, column=2)
button9 = tk.Button(window, text="9", command=lambda: add_to_calc(9), width=5, font=('Arial', 14))
button9.grid(row=4, column=3)
button0 = tk.Button(window, text="0", command=lambda: add_to_calc(0), width=5, font=('Arial', 14))
button0.grid(row=5, column=2)

buttonAdd = tk.Button(window, text="+", command=lambda: addOper(), \
                      width=5,\
                      font=('Arial', 14))
buttonAdd.grid(row=5,column=1) # JCT add this
buttonSubtract = tk.Button(window, text="-", command=lambda: subOper(), \
                      width=5,\
                      font=('Arial', 14))
buttonSubtract.grid(row=6,column=1)
buttonMultiply = tk.Button(window, text="*", command=lambda: mulOper(), \
                      width=5,\
                      font=('Arial', 14))
buttonMultiply.grid(row=6,column=2)
buttonDivide = tk.Button(window, text="/", command=lambda: divOper(), \
                      width=5,\
                      font=('Arial', 14))
buttonDivide.grid(row=5,column=3)


               




window.mainloop() # executes main module
